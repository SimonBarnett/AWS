// nodejs/helpers.js
// CENTRAL ORCHESTRATOR - MADEIRA CORE LAYER
// Re-exports everything. Consumers only ever import from this file.

const winston = require('winston');
const sql = require('mssql');
const bcrypt = require('bcrypt');

// ====================== AWS SDK IMPORTS ======================
const { 
    S3Client, 
    GetObjectCommand, 
    PutObjectCommand, 
    ListObjectsV2Command,
    DeleteObjectCommand,
    DeleteObjectsCommand,
    HeadObjectCommand,
    CopyObjectCommand 
} = require("@aws-sdk/client-s3");

const { SQSClient, SendMessageCommand } = require("@aws-sdk/client-sqs");
const { SSMClient, GetParametersCommand, PutParameterCommand } = require("@aws-sdk/client-ssm");
const { LambdaClient, InvokeCommand } = require("@aws-sdk/client-lambda");

// ====================== SHARED LOGGER ======================
const logger = winston.createLogger({
    level: process.env.LOG_LEVEL || 'debug',
    format: winston.format.combine(
        winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
        winston.format.errors({ stack: true }),
        winston.format.json()
    ),
    transports: [new winston.transports.Console()],
    defaultMeta: { service: 'madeira-shared-layer' }
});

logger.debug('Shared Layer orchestrator loaded');

// ====================== SHARED REGION BOOTSTRAP ======================
const BOOTSTRAP_REGION = process.env.AWS_REGION || 'eu-west-2';

let awsRegionCache = null;
let awsRegionCacheTime = 0;

async function getAwsRegion() {
    const now = Date.now();
    if (awsRegionCache && (now - awsRegionCacheTime < 1800000)) return awsRegionCache;

    logger.info('🔄 Determining AWS Region (bootstrap → SSM override)');

    try {
        let region = process.env.AWS_REGION || BOOTSTRAP_REGION;
        const client = new SSMClient({ region: BOOTSTRAP_REGION });
        const command = new GetParametersCommand({ Names: ["/madeira/aws-region"], WithDecryption: true });
        const response = await client.send(command);
        const ssmRegion = response.Parameters?.[0]?.Value;

        if (ssmRegion) {
            region = ssmRegion;
            logger.info(`✅ Using SSM override region: ${region}`);
        } else {
            logger.info(`✅ Using runtime region: ${region} (no SSM override found)`);
        }

        awsRegionCache = region;
        awsRegionCacheTime = now;
        return region;
    } catch (error) {
        logger.warn('Failed to check SSM region override, using bootstrap', { error: error.message });
        awsRegionCache = BOOTSTRAP_REGION;
        awsRegionCacheTime = now;
        return BOOTSTRAP_REGION;
    }
}

// ====================== SHARED CLIENTS ======================
let s3ClientCache = null;
let s3RegionCache = null;

async function getS3Client() {
    const region = await getAwsRegion();
    if (s3ClientCache && s3RegionCache === region) return s3ClientCache;
    logger.debug('Creating new S3 client', { region });
    s3ClientCache = new S3Client({ region });
    s3RegionCache = region;
    return s3ClientCache;
}

let sqsClientCache = null;
let sqsRegionCache = null;

async function getSQSClient() {
    const region = await getAwsRegion();
    if (sqsClientCache && sqsRegionCache === region) return sqsClientCache;
    logger.debug('Creating new SQS client', { region });
    sqsClientCache = new SQSClient({ region });
    sqsRegionCache = region;
    return sqsClientCache;
}

let ssmClientCache = null;
let ssmRegionCache = null;

async function getSSMClient() {
    const region = await getAwsRegion();
    if (ssmClientCache && ssmRegionCache === region) return ssmClientCache;
    logger.debug('Creating new SSM client', { region });
    ssmClientCache = new SSMClient({ region });
    ssmRegionCache = region;
    return ssmClientCache;
}

let lambdaClientCache = null;
let lambdaRegionCache = null;

async function getLambdaClient() {
    const region = await getAwsRegion();
    if (lambdaClientCache && lambdaRegionCache === region) return lambdaClientCache;

    logger.debug('Creating new Lambda client for shared layer', { region });
    lambdaClientCache = new LambdaClient({ region });
    lambdaRegionCache = region;
    return lambdaClientCache;
}

// ====================== SHARED SSM HELPER ======================
async function createPlaceholderIfMissing(client, name, placeholder = "CHANGE_ME") {
    try {
        logger.warn(`🆕 Creating missing SSM parameter: ${name} = ${placeholder}`);
        await client.send(new PutParameterCommand({
            Name: name,
            Value: placeholder,
            Type: "String",
            Overwrite: true
        }));
        return placeholder;
    } catch (err) {
        logger.error(`Failed to create placeholder for ${name}`, { error: err.message });
        return placeholder;
    }
}

// ====================== BCRYPT HELPERS ======================
async function hashPassword(password) {
    const transactionId = `bcrypt-hash-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

    try {
        if (!password || typeof password !== 'string') {
            logger.error('Password hashing failed - invalid password', { transactionId });
            throw new Error('Password is required and must be a string');
        }

        logger.debug('🔐 Hashing password', { transactionId });

        const hash = await bcrypt.hash(password, 12);

        logger.debug('✅ Password hashed successfully', { 
            transactionId,
            hashLength: hash.length 
        });

        return hash;

    } catch (error) {
        logger.error('❌ Password hashing failed', {
            transactionId,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

async function comparePassword(password, hash) {
    const transactionId = `bcrypt-compare-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

    try {
        if (!password || typeof password !== 'string' || !hash || typeof hash !== 'string') {
            logger.error('Password comparison failed - invalid inputs', { transactionId });
            throw new Error('Both password and hash are required and must be strings');
        }

        logger.debug('🔐 Comparing password', { transactionId });

        const match = await bcrypt.compare(password, hash);

        logger.debug('✅ Password comparison completed', { 
            transactionId,
            match 
        });

        return match;

    } catch (error) {
        logger.error('❌ Password comparison failed', {
            transactionId,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

// ====================== SQS ENQUEUE ======================
const SQS_QUEUE_URL = process.env.SQS_QUEUE_URL;

async function enqueueMessage(message) {
    const transactionId = `sqs-enqueue-${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;

    if (!SQS_QUEUE_URL) {
        logger.error('SQS enqueue failed - SQS_QUEUE_URL not set', { transactionId });
        throw new Error('SQS_QUEUE_URL environment variable is not set');
    }
    if (!message || typeof message !== 'object') {
        throw new Error('enqueueMessage requires a valid message object');
    }

    const isFifoQueue = SQS_QUEUE_URL.toLowerCase().endsWith('.fifo');

    const params = {
        QueueUrl: SQS_QUEUE_URL,
        MessageBody: JSON.stringify(message)
    };

    if (isFifoQueue) {
        params.MessageGroupId = message.userId || message.catalogId || message.type || 'default';
        params.MessageDeduplicationId = `${message.userId || message.catalogId || 'default'}-${Date.now()}-${Math.random().toString(36).substring(2, 12)}`;
    }

    try {
        const sqs = await getSQSClient();
        await sqs.send(new SendMessageCommand(params));
        logger.debug('✅ Message enqueued to SQS', { 
            transactionId,
            type: message.type,
            affiliate: message.affiliate || 'N/A',
            catalogId: message.catalogId,
            isFifoQueue
        });
        return { success: true, transactionId };
    } catch (error) {
        logger.error('❌ SQS enqueue failed', { transactionId, error: error.message });
        throw error;
    }
}

// ====================== FINAL RE-EXPORTS (MAIN FUNCTIONS FIRST) ======================
module.exports = {
    sql,
    logger,
    getAwsRegion,
    getS3Client,
    getSQSClient,
    getLambdaClient,
    getSSMClient,
    InvokeCommand,
    GetObjectCommand,
    PutObjectCommand,
    ListObjectsV2Command,
    DeleteObjectCommand,
    DeleteObjectsCommand,
    HeadObjectCommand,
    CopyObjectCommand,
    GetParametersCommand,
    SendMessageCommand,
    enqueueMessage,
    hashPassword,
    comparePassword,
    createPlaceholderIfMissing
};

// ====================== IMPORT CONFIG MODULES (AFTER MAIN EXPORTS) ======================
const dbConfig = require('./conf/db-config');
const grokConfig = require('./conf/grok-config');
const mailerConfig = require('./conf/mailer-config');
const smsConfig = require('./conf/sms-config');
const jwtConfig = require('./conf/jwt-config');
const stripeConfig = require('./conf/stripe-config');
const ebayConfig = require('./conf/ebay-config');
const amazonConfig = require('./conf/amazon-config');
const awinConfig = require('./conf/awin-config');

// Add config getters to exports
Object.assign(module.exports, {
    getDbConnection: dbConfig.getDbConnection,
    getDbConfig: dbConfig.getDbConfig,
    getGrokConfig: grokConfig.getGrokConfig,
    getMailerConfig: mailerConfig.getMailerConfig,
    getSmsConfig: smsConfig.getSmsConfig,
    getJwtConfig: jwtConfig.getJwtConfig,
    getStripeConfig: stripeConfig.getStripeConfig,
    getEbayConfig: ebayConfig.getEbayConfig,
    getAmazonConfig: amazonConfig.getAmazonConfig,
    getAwinConfig: awinConfig.getAwinConfig,
});

logger.info('✅ Madeira core layer orchestrator loaded — circular dependency resolved');