// nodejs/conf/db-config.js
const sql = require('mssql');  // ← Import sql directly here
const { GetParametersCommand } = require('/opt/nodejs/helpers');
const { getAwsRegion, getSSMClient, createPlaceholderIfMissing } = require('/opt/nodejs/helpers');

let cache = null;
let cacheTime = 0;

async function getDbConfig() {
    const now = Date.now();
    if (cache && (now - cacheTime < 1800000)) return cache;

    const region = await getAwsRegion();
    const client = await getSSMClient();

    const command = new GetParametersCommand({
        Names: [
            "/madeira/db/user",
            "/madeira/db/password",
            "/madeira/db/server",
            "/madeira/db/name"
        ],
        WithDecryption: true
    });

    const response = await client.send(command);
    const existing = {};
    response.Parameters.forEach(p => {
        existing[p.Name.split('/').pop()] = p.Value;
    });

    const defaults = {
        user: "madeira_app",
        server: "madeira-db-server.database.windows.net",
        name: "madeiradb"
    };

    for (const [key, value] of Object.entries(defaults)) {
        if (!existing[key]) {
            await createPlaceholderIfMissing(client, `/madeira/db/${key}`, value);
        }
    }
    if (!existing.password) {
        await createPlaceholderIfMissing(client, "/madeira/db/password", "CHANGE_ME");
    }

    const config = {
        user: process.env.DB_USER || existing.user,
        password: process.env.DB_PASSWORD || existing.password,
        server: process.env.DB_SERVER || existing.server,
        database: process.env.DB_NAME || existing.name
    };

    cache = config;
    cacheTime = now;
    return config;
}

async function getDbConnection() {
    const config = await getDbConfig();
    const pool = await sql.connect({
        user: config.user,
        password: config.password,
        server: config.server,
        database: config.database,
        options: {
            encrypt: true,
            trustServerCertificate: true,
            requestTimeout: 300000
        }
    });
    return pool;
}

module.exports = { getDbConfig, getDbConnection };