// routes/onboarding.js
const fetch = require('node-fetch');
const sql = require('mssql');
const { logger, invokeMailer, createAwinMerchantUser, getDbConnection } = require('../helpers');

const PUBLISHER_ID = process.env.AWIN_PUBLISHER_ID;
const ACCESS_TOKEN = process.env.AWIN_ACCESS_TOKEN;
const NOTIFICATION_EMAIL_TO = process.env.NOTIFICATION_EMAIL_TO || 'stakeholder@clubmadeira.uk';

// ====================== MAIN HANDLER ======================
exports.handler = async (event) => {
    const sandbox = event.sandbox === true;
    const newAdvertisers = [];
    let pool = null;

    try {
        pool = await getDbConnection();

        if (!sandbox) {
            const programmes = await getJoinedProgrammes();
            logger.info(`Fetched ${programmes.length} joined Awin programmes`);

            for (const prog of programmes) {
                const name = prog.name?.trim() || 'Unknown Advertiser';
                const advertiserId = String(prog.id);
                const email = prog.contactEmail || prog.email || prog.primaryContactEmail || `${advertiserId}@awin.com`;
                const website = prog.displayUrl || prog.website || prog.siteUrl || '';
                const logoUrl = prog.logoUrl || '';
                const primarySector = prog.primarySector || '';
                const description = prog.description || '';

                if (await emailAlreadyExists(email, pool)) continue;

                const user = await createAwinMerchantUser({ advertiserId, name, website }, pool);

                // Save user_id into AwinHighApprovalMerchants
                await pool.request()
                    .input('merchantId', sql.BigInt, advertiserId)
                    .input('userId', sql.VarChar(20), user.userId)
                    .query(`
                        UPDATE dbo.AwinHighApprovalMerchants
                        SET AwinUserId = @userId
                        WHERE MerchantId = @merchantId
                    `);

                newAdvertisers.push({ 
                    user_id: user.userId, 
                    company_name: name, 
                    email: user.email,
                    website: website,
                    logoUrl: logoUrl,
                    primarySector: primarySector,
                    description: description
                });
            }
        } else {
            logger.info('🧪 SANDBOX MODE – Selecting 8 random joined merchants');
            const randomResult = await pool.request().query(`
                SELECT TOP 8
                    MerchantId as id,
                    Name as company_name,
                    Email as email,
                    Website as website,
                    logoUrl,
                    primarySector,
                    description
                FROM dbo.AwinHighApprovalMerchants
                WHERE Joined = 1
                ORDER BY NEWID()
            `);
            newAdvertisers.push(...randomResult.recordset);
        }

        logger.info('Fetching Awin stats for director report...');
        const stats = await getAwinStats(pool);

        if (newAdvertisers.length > 0) {
            const emailTo = sandbox ? 'si@ntsa.uk' : NOTIFICATION_EMAIL_TO;

            const projectedTotalMerchants = stats.totalAwinMerchants + (sandbox ? 0 : newAdvertisers.length);

            // ====================== NEW MERCHANTS TABLE ======================
            const newTableRows = newAdvertisers
                .map(a => {
                    const emailValue = a.email || `${a.id}@awin.com`;
                    const loginLink = `https://partner.clubmadeira.io/login.html?uid=${encodeURIComponent(emailValue)}`;

                    const logoHtml = a.logoUrl 
                        ? `<a href="${a.website || '#'}" target="_blank">
                             <img src="${a.logoUrl}" alt="${a.company_name}" style="max-height:60px; max-width:140px;">
                           </a><br>
                           <small style="font-size:14px;">${a.primarySector || ''}</small>`
                        : `<strong>${a.company_name}</strong>`;

                    return `
                        <tr>
                            <td style="text-align:center; vertical-align:middle;">${logoHtml}</td>
                            <td>${a.description ? a.description.substring(0, 150) + '...' : '—'}</td>
                            <td>
                                <a href="${loginLink}" target="_blank" style="color:#0066cc; text-decoration:underline;">
                                    ${emailValue}
                                </a>
                            </td>
                        </tr>`;
                })
                .join('');

            const newMerchantsTable = `
                <h3>New Awin Merchants Onboarded Today (${newAdvertisers.length})</h3>
                <table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse; width:100%; font-size:14px;">
                    <thead>
                        <tr style="background:#f0f0f0;">
                            <th style="width:160px;">Company</th>
                            <th style="text-align:left;">Description</th>
                            <th style="text-align:left;">Email</th>
                        </tr>
                    </thead>
                    <tbody>${newTableRows}</tbody>
                </table>
            `;

            // Top 10 Table (unchanged)
            const topTableRows = stats.topMerchants
                .map(m => {
                    const logoHtml = m.logoUrl 
                        ? `<a href="${m.website || '#'}" target="_blank">
                             <img src="${m.logoUrl}" alt="${m.company_name}" style="max-height:60px; max-width:140px;">
                           </a><br>
                           <small style="font-size:14px;">${m.primarySector || ''}</small>`
                        : `<strong>${m.company_name}</strong>`;
                    return `
                        <tr>
                            <td style="text-align:center; vertical-align:middle;">${logoHtml}</td>
                            <td>${m.description ? m.description.substring(0, 150) + '...' : '—'}</td>
                            <td style="text-align:right; font-weight:bold;">${m.merchant_parts_count.toLocaleString()}</td>
                        </tr>`;
                })
                .join('');

            const topMerchantsHtml = `
                <h3>Top 10 Awin Merchants by Product Count</h3>
                <table border="1" cellpadding="8" cellspacing="0" style="border-collapse:collapse; width:100%; font-size:14px;">
                    <thead>
                        <tr style="background:#f0f0f0;">
                            <th style="width:160px;">Company</th>
                            <th style="text-align:left;">Description</th>
                            <th style="text-align:right;">Parts Count</th>
                        </tr>
                    </thead>
                    <tbody>${topTableRows}</tbody>
                </table>
            `;

            const sandboxBanner = sandbox ? `
                <div style="background:#ff9800; color:#fff; padding:15px; text-align:center; font-size:18px; font-weight:bold;">
                    🚨 SANDBOX MODE — Showing 8 random joined advertisers for email layout testing
                </div>
            ` : '';

            const mailOptions = {
                from: 'support@clubmadeira.uk',
                to: emailTo,
                subject: `${sandbox ? '[SANDBOX TEST] ' : ''}Awin Merchant Onboarding Report - ${new Date().toISOString().split('T')[0]}`,
                html: `
                    ${sandboxBanner}
                    <h2>Awin Merchant Onboarding Report</h2>
                    <p><strong>Sync completed at:</strong> ${new Date().toISOString()}</p>
                    <hr>
                    <h3>Overall Awin Statistics</h3>
                    <ul>
                        <li><strong>Total Awin Merchants (after this sync):</strong> ${projectedTotalMerchants.toLocaleString()}</li>
                        <li><strong>Total Awin Parts / Products:</strong> ${stats.totalAwinParts.toLocaleString()}</li>
                    </ul>
                    <hr>
                    ${newMerchantsTable}
                    <hr>
                    ${topMerchantsHtml}
                    <hr>
                    <p style="font-size:12px; color:#666;">
                        This report was automatically generated by the <strong>madeira-awin-clubscan</strong> onboarding route.
                    </p>
                `
            };

            await invokeMailer(mailOptions);
            logger.info(`✅ Report sent successfully to ${emailTo}`);
        } else {
            logger.info('No new Awin merchants found this run — no email sent');
        }

        return { 
            statusCode: 200, 
            added: newAdvertisers.length,
            totalAwinMerchants: stats.totalAwinMerchants,
            totalAwinParts: stats.totalAwinParts,
            sandboxMode: sandbox
        };

    } catch (error) {
        logger.error(`Awin onboarding failed: ${error.message}`, { stack: error.stack });
        throw error;
    } finally {
        if (pool) await pool.close();
    }
};

// ====================== HELPERS ======================
async function getJoinedProgrammes() {
    const url = `https://api.awin.com/publishers/${PUBLISHER_ID}/programmes?relationship=joined`;
    const response = await fetch(url, {
        headers: { Authorization: `Bearer ${ACCESS_TOKEN}` }
    });
    if (!response.ok) throw new Error(`Awin API error: ${response.status}`);
    return await response.json();
}

async function emailAlreadyExists(email, pool) {
    const result = await pool.request()
        .input('email', sql.VarChar, email)
        .query(`SELECT 1 FROM Users WHERE email_address = @email`);
    return result.recordset.length > 0;
}

async function getAwinStats(pool) {
    const totalMerchantsResult = await pool.request().query(`
        SELECT COUNT(DISTINCT u.user_id) AS totalAwinMerchants
        FROM [madeiradb].[dbo].[Users] u
        INNER JOIN [madeiradb].[dbo].[UserApiKeys] uak 
            ON uak.user_id = u.user_id
        WHERE uak.api_key_type = 'awin'
        AND u.referrer IS NULL
    `);
    const totalAwinMerchants = totalMerchantsResult.recordset[0].totalAwinMerchants || 0;

    const totalPartsResult = await pool.request().query(`
        SELECT COUNT(*) AS totalAwinParts
        FROM [madeiradb].[dbo].[MerchantProducts]
        WHERE Source = 'awin'
    `);
    const totalAwinParts = totalPartsResult.recordset[0].totalAwinParts || 0;

    const topMerchantsResult = await pool.request().query(`
        SELECT TOP 10
            ahm.MerchantId as id,
            ahm.Name as company_name,
            ahm.Website as website,
            ahm.logoUrl,
            ahm.primarySector,
            ahm.description,
            ISNULL((
                SELECT COUNT(*)
                FROM [madeiradb].[dbo].[MerchantProducts] mp
                WHERE mp.UserId = ahm.AwinUserId
                  AND mp.Source = 'awin'
            ), 0) AS merchant_parts_count
        FROM dbo.AwinHighApprovalMerchants ahm
        WHERE ahm.Joined = 1
          AND ahm.AwinUserId IS NOT NULL
        ORDER BY merchant_parts_count DESC
    `);

    return {
        totalAwinMerchants,
        totalAwinParts,
        topMerchants: topMerchantsResult.recordset
    };
}